#import "CPTDerivedXYGraph.h"

/**
 *	@brief An empty XY graph class used for testing themes.
 **/
@implementation CPTDerivedXYGraph

@end
