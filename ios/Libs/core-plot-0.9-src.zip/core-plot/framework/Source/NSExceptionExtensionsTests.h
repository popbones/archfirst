#import "CPTTestCase.h"

@interface NSExceptionExtensionsTests : CPTTestCase {
}

@end
