#import "CPTTestCase.h"

@interface CPTUtilitiesTests : CPTTestCase {
}

@end
