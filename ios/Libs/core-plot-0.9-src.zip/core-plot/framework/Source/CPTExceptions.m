#import "CPTExceptions.h"

NSString *const CPTException			= @"CPTException";            ///< General Core Plot exceptions.
NSString *const CPTDataException		= @"CPTDataException";        ///< Core Plot data exceptions.
NSString *const CPTNumericDataException = @"CPTNumericDataException"; ///< Core Plot numeric data exceptions.
