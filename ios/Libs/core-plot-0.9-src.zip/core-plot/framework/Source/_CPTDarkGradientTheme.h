#import "_CPTXYTheme.h"

@interface _CPTDarkGradientTheme : _CPTXYTheme {
}

@end
