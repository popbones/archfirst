#import "CPTTestCase.h"

@class CPTMutablePlotRange;

@interface CPTPlotRangeTests : CPTTestCase {
	CPTMutablePlotRange *plotRange;
}

@property (retain, readwrite) CPTMutablePlotRange *plotRange;

@end
