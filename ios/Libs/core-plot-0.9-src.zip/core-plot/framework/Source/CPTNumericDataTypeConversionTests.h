#import "CPTTestCase.h"

@interface CPTNumericDataTypeConversionTests : CPTTestCase {
}

@end
