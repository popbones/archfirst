#import "CPTTestCase.h"

@interface CPTMutableNumericDataTypeConversionTests : CPTTestCase {
}

@end
