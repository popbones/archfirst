#import "CPTTestCase.h"

@class CPTXYGraph;

@interface CPTPlotSpaceTests : CPTTestCase {
    CPTXYGraph *graph;
}

@property (retain, readwrite) CPTXYGraph *graph;

@end
