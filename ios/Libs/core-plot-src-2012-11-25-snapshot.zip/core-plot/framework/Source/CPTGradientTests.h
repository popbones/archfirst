#import "CPTTestCase.h"

@interface CPTGradientTests : CPTTestCase {
}

@end
