#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef UIImage CPTNativeImage; ///< Platform-native image format.
typedef UIEvent CPTNativeEvent; ///< Platform-native OS event.
