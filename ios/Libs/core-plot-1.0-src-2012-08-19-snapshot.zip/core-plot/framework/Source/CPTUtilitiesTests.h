#import "CPTTestCase.h"

@interface CPTUtilitiesTests : CPTTestCase {
    CGContextRef context;
}

@property (readwrite, assign) CGContextRef context;

@end
