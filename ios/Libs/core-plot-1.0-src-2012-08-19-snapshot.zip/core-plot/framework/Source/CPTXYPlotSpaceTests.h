#import "CPTTestCase.h"

@class CPTXYGraph;

@interface CPTXYPlotSpaceTests : CPTTestCase {
    CPTXYGraph *graph;
}

@property (retain, readwrite) CPTXYGraph *graph;

@end
