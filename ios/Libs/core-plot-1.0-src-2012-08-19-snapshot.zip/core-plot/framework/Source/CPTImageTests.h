#import "CPTTestCase.h"

@interface CPTImageTests : CPTTestCase {
}

@end
