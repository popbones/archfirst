#import "CPTTestCase.h"

@interface CPTColorTests : CPTTestCase {
}

@end
