#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef UIImage CPTNativeImage;
typedef UIEvent CPTNativeEvent; ///< Platform-native OS event.
